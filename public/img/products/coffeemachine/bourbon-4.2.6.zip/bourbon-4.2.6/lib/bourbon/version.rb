module Bourbon
  VERSION = "4.2.6"
end
